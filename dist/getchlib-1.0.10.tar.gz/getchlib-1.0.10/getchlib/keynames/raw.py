
F1 = 'P'
F2 = 'Q'
F3 = 'R'
F4 = 'S'

UP = 'A'
DOWN = 'B'
RIGHT = 'C'
LEFT = 'D'

KEYPAD_0 = 'p'
KEYPAD_1 = 'q'
KEYPAD_2 = 'r'
KEYPAD_3 = 's'
KEYPAD_4 = 't'
KEYPAD_5 = 'u'
KEYPAD_6 = 'v'
KEYPAD_7 = 'w'
KEYPAD_8 = 'x'
KEYPAD_9 = 'y'
KEYPAD_MINUS = 'm'
KEYPAD_COMMA = 'l'
KEYPAD_PERIOD = 'n'
KEYPAD_ENTER = 'M'
F1 = '11~'
F2 = '12~'
F3 = '13~'
F4 = '14~'
F5 = '15~'

F6 = '17~'
F7 = '18~'
F8 = '19~'
F9 = '20~'
F10 = '21~'
F11 = '23~'
F12 = '24~'


HOME = 'H'
END = 'F'
PAGE_UP = '5'
PAGE_DOWN = '6'



INSERT = '2~'
DELETE = '3~'

